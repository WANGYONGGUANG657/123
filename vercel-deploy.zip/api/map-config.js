// Vercel Serverless Function 用于安全地提供高德地图 API 密钥
// 文件路径: /api/map-config.js

export default function handler(req, res) {
    // 从环境变量读取 API 密钥
    const amapKey = process.env.AMAP_API_KEY || '';

    // 设置 CORS 头
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET');
    res.setHeader('Content-Type', 'application/json');

    // 返回配置
    res.status(200).json({
        amapKey: amapKey,
        amapVersion: '2.0',
        amapPlugins: 'AMap.Scale,AMap.ToolBar'
    });
}
