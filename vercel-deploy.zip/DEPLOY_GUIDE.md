# 🏝️ 海南家庭旅游计划 - Vercel部署指南

## ✅ 修复404错误 - 快速解决方案

如果您遇到了 **404: NOT_FOUND** 错误，请按照以下步骤操作：

### 方法1：直接在Vercel重新部署（最简单）

1. **删除旧部署**
   - 登录 [Vercel Dashboard](https://vercel.com/dashboard)
   - 找到您的项目
   - 进入 Settings → General
   - 滚动到底部，点击 "Delete Project"

2. **重新上传项目**
   - 确保您上传的是 `deploy` 文件夹的**内容**，而不是文件夹本身
   - 项目根目录应该包含：
     ```
     ├── index.html          ← 必须在根目录
     ├── api/
     │   └── map-config.js
     ├── vercel.json
     ├── package.json
     └── README.md
     ```

3. **配置环境变量**
   - 在Vercel项目设置中
   - 进入 Settings → Environment Variables
   - 添加变量：
     - Name: `AMAP_API_KEY`
     - Value: 您的高德地图API密钥

4. **重新部署**
   - Vercel会自动检测并部署

---

## 📁 正确的项目结构

您的Vercel项目根目录应该是这样的：

```
your-project/           ← Vercel项目根目录
├── index.html          ← 主页面（重要！必须在根目录）
├── api/                ← Serverless Functions
│   └── map-config.js   ← API密钥接口
├── vercel.json         ← Vercel配置（简化版）
├── package.json        ← 项目配置
├── .env.example        ← 环境变量示例
├── .gitignore          ← Git忽略文件
└── README.md           ← 本文档
```

⚠️ **常见错误**：上传了包含 `public` 文件夹的结构
```
❌ 错误结构：
your-project/
└── public/
    └── index.html     ← 错误！Vercel找不到

✅ 正确结构：
your-project/
└── index.html         ← 正确！在根目录
```

---

## 🚀 完整部署步骤

### 方式A：通过Git仓库部署（推荐）

#### 1. 准备Git仓库

```bash
# 进入deploy文件夹
cd deploy

# 初始化Git
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit: Hainan travel plan"

# 连接到您的GitHub仓库
git remote add origin https://github.com/your-username/your-repo.git
git branch -M main
git push -u origin main
```

#### 2. 在Vercel导入项目

1. 访问 [Vercel](https://vercel.com)
2. 点击 "New Project"
3. 选择 "Import Git Repository"
4. 选择您刚才创建的仓库
5. **重要配置**：
   - Framework Preset: 选择 "Other"
   - Root Directory: `.` （保持默认）
   - Build Command: 留空
   - Output Directory: 留空
6. 点击 "Deploy"

#### 3. 配置环境变量

1. 部署完成后，进入项目设置
2. 点击 "Settings" → "Environment Variables"
3. 添加环境变量：
   ```
   Name:  AMAP_API_KEY
   Value: 您的高德地图API密钥
   ```
4. 点击 "Save"
5. 回到 "Deployments" 页面
6. 点击最新部署右侧的 "..." → "Redeploy"

---

### 方式B：直接拖拽上传

1. 访问 [Vercel](https://vercel.com)
2. 点击 "New Project"
3. 选择 "Upload"
4. **重要**：拖拽 `deploy` 文件夹中的**所有文件**（不是文件夹本身）
5. 或者创建一个zip文件：
   ```bash
   cd deploy
   # 将deploy文件夹的内容打包（不包含deploy文件夹本身）
   zip -r ../hainan-travel.zip * .env.example .gitignore
   ```
6. 上传zip文件
7. 配置环境变量（同方式A步骤3）

---

## 🔍 验证部署是否成功

部署完成后，访问您的Vercel链接，您应该看到：

### ✅ 成功标志
- 页面正常显示标题："🏝️ 海南家庭旅游计划"
- 行程时间轴正常显示
- 图片正常加载
- 地图区域显示（如果配置了API密钥）

### ❌ 如果还是404
1. 检查浏览器地址栏，确保访问的是 `https://your-project.vercel.app/`（注意最后的斜杠）
2. 检查Vercel Dashboard中的 "Functions" 标签，确保 `/api/map-config` 函数存在
3. 查看Vercel Logs（在项目页面点击 "View Function Logs"）

---

## 🔧 常见问题排查

### 问题1: 404 NOT_FOUND

**原因**：文件结构不正确

**解决方案**：
```bash
# 检查deploy文件夹内容
cd deploy
ls -la

# 应该看到这些文件在当前目录：
# index.html
# api/
# vercel.json
# package.json
```

如果 `index.html` 在 `public/` 文件夹内，运行：
```bash
mv public/index.html ./
rmdir public
```

### 问题2: 地图不显示

**可能原因1**：未配置环境变量

**解决方案**：
1. Vercel Dashboard → 您的项目 → Settings → Environment Variables
2. 添加 `AMAP_API_KEY`
3. Redeploy项目

**可能原因2**：API密钥无效

**解决方案**：
1. 访问 [高德开放平台](https://lbs.amap.com/)
2. 检查您的API Key是否有效
3. 确认Key的服务平台选择了 "Web端(JS API)"

### 问题3: Serverless Function 报错

**检查步骤**：
1. 访问 `https://your-project.vercel.app/api/map-config`
2. 应该返回JSON：
   ```json
   {
     "amapKey": "your_key_here",
     "amapVersion": "2.0",
     "amapPlugins": "AMap.Scale,AMap.ToolBar"
   }
   ```
3. 如果返回错误，检查 `api/map-config.js` 文件是否存在

---

## 📱 本地测试

在上传到Vercel之前，可以本地测试：

```bash
# 安装Vercel CLI
npm install -g vercel

# 进入项目目录
cd deploy

# 创建.env文件
echo "AMAP_API_KEY=your_actual_key_here" > .env

# 启动本地开发服务器
vercel dev

# 访问 http://localhost:3000
```

---

## 🎯 项目特点

- ✅ **安全**：API密钥存储在服务器端环境变量
- ✅ **简单**：使用Vercel原生功能，无需额外配置
- ✅ **快速**：静态文件CDN加速
- ✅ **免费**：Vercel免费计划完全够用

---

## 📞 需要帮助？

如果按照以上步骤仍然遇到问题，请检查：

1. ✅ `index.html` 是否在项目根目录
2. ✅ `api/map-config.js` 文件是否存在
3. ✅ `vercel.json` 配置是否正确（应该只有 `{"version": 2}`）
4. ✅ 环境变量 `AMAP_API_KEY` 是否已配置
5. ✅ 是否已经 Redeploy 项目

---

## 📋 部署检查清单

在部署前，确认：

- [ ] `index.html` 在根目录
- [ ] `api` 文件夹包含 `map-config.js`
- [ ] `vercel.json` 配置正确
- [ ] `.gitignore` 已添加（避免上传 `.env`）
- [ ] 已获取高德地图 API 密钥
- [ ] 准备在 Vercel 配置环境变量

部署后，验证：

- [ ] 访问首页无404错误
- [ ] 行程时间轴正常显示
- [ ] 图片正常加载
- [ ] 地图API endpoint 正常工作 (`/api/map-config`)

---

## 🎉 部署成功！

部署成功后，您将获得：
- 一个公开的URL（如 `https://your-project.vercel.app`）
- 自动HTTPS
- 全球CDN加速
- 免费托管

分享您的旅行计划链接给家人和朋友吧！ 🏝️✨
